from rest_framework import serializers
from .models import Cliente

class ClienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cliente
        fields = '__all__' 

    def validate_cpf(self, value):        
        cpf_limpo = value.replace('.', '').replace('-', '')
        
        if len(cpf_limpo) != 11:
            raise serializers.ValidationError("O CPF deve conter exatamente 11 dígitos.")
        
        return cpf_limpo 

    def validate_email(self, value):
        if(not value):
            raise serializers.ValidationError("O e-mail é obrigatório.")
        
        if Cliente.objects.filter(email=value).exists():
            raise serializers.ValidationError("Este e-mail já está em uso.")
        return value
