from django.db import models
from django.core.exceptions import ValidationError

def validar_idade_minima(data_nascimento):
    from datetime import date, timedelta
    idade_minima = 18
    data_atual = date.today()
    idade = data_atual - data_nascimento

    if idade < timedelta(days=idade_minima * 365):
        raise ValidationError("O cliente deve ter pelo menos 18 anos de idade.")

class Cliente(models.Model):
    nome = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    cpf = models.TextField(max_length=11, blank=False, null=False)
    data_nascimento = models.DateField(validators=[validar_idade_minima])

    def __str__(self):
        return self.nome
